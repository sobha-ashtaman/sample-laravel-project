<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class BookResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'title' => $this->title,
            'slug' => $this->slug,
            'author' => [
                'id' => $this->author->id,
                'name' => $this->author->name
            ],
            'short_description' => $this->short_description,
            'description' => $this->description,
            'cover_image' => $this->cover_image,
            'genres' => GenreResource::collection($this->genres),
            'status' => $this->status,
            'created_by_user' =>[
                'id' => $this->created_user->id,
                'name' => $this->updated_user->name
            ],
            'updated_by_user' =>[
                'id' => $this->created_user->id,
                'name' => $this->updated_user->name
            ],
            'created_at' => date('d-m-Y h:i A', strtotime($this->created_at)),
            'updated_at' => date('d-m-Y h:i A', strtotime($this->updated_at))
        ];
    }
}
